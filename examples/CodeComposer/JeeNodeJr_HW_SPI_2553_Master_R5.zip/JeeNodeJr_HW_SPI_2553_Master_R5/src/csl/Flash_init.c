/*
 *  ==== DO NOT MODIFY THIS FILE - CHANGES WILL BE OVERWRITTEN ====
 *
 *  Generated from
 *      C:/Program Files/Texas Instruments/grace_1_00_01_83/packages/ti/mcu/msp430/csl/memory/Flash_init.xdt
 */

#include <ti/mcu/msp430/include/msp430.h>

/*
 *  ======== Flash_2xx_init ========
 *  Initialize MSP430F2xx Family Flash Module
 */
void Flash_init(void)
{
    /* nothing to do, the reset values are sufficient for this configuration */
}
