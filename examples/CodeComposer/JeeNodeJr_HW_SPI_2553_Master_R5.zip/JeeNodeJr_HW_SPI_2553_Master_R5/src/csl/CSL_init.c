/*
 *  ======== CSL_init.c ========
 *  DO NOT MODIFY THIS FILE - CHANGES WILL BE OVERWRITTEN
 */
 
/* external peripheral initialization functions */
extern void WDTplus_init(void);
extern void Flash_init(void);
extern void GPIO_init(void);
extern void BCSplus_init(void);
extern void USCI_B0_init(void);
extern void System_init(void);

/*
 *  ======== CSL_init =========
 *  Initialize all configured CSL peripherals
 */
void CSL_init(void)
{
    /* initialize Config for the MSP430 WDT+ */
    WDTplus_init();

    /* initialize Config for the MSP430F2xx Flash Memory Controller */
    Flash_init();

    /* initialize Config for the MSP430 GPIO */
    GPIO_init();

    /* initialize Config for the MSP430 2xx family clock systems (BCS) */
    BCSplus_init();

    /* initialize Config for the MSP430 USCI_B0 */
    USCI_B0_init();

    /* initialize Config for the MSP430 System Registers */
    System_init();

}

/*
 *  ======== Interrupt Function Definitions ========
 */

#include <ti/mcu/msp430/include/msp430.h>

/* Interrupt Function Prototypes */
extern void PORT_2_RFM12B_ISR(void);
extern void WDT_INTERVAL_ISR(void);


/*
 *  ======== PORT2 Interrupt Service Routine ========
 */
#pragma vector=PORT2_VECTOR
__interrupt void PORT2_ISR_HOOK(void)
{


	/* Port 2 Interrupt Handler */
	PORT_2_RFM12B_ISR();

	/* No change in operating mode on exit */
}

/*
 *  ======== Watchdog Timer Interval Interrupt Handler Generation ========
 */
#pragma vector=WDT_VECTOR
__interrupt void WDT_ISR_HOOK(void)
{


	/* Watchdog Timer Interrupt Handler */
	WDT_INTERVAL_ISR();

	/* No change in operating mode on exit */
}
