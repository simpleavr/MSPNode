/*
 *  ==== DO NOT MODIFY THIS FILE - CHANGES WILL BE OVERWRITTEN ====
 *
 *  Generated from
 *      C:/Program Files/Texas Instruments/grace_1_00_01_83/packages/ti/mcu/msp430/csl/system/System_init.xdt
 */

#include <ti/mcu/msp430/include/msp430.h>

/*
 *  ======== System_init ========
 *  Initialize MSP430 Status Register
 */
void System_init(void)
{
    /* 
     * IFG1, Interrupt Flag Register 1
     * 
     * ~ACCVIFG -- No interrupt pending
     * ~NMIIFG -- No interrupt pending
     * ~OFIFG -- No interrupt pending
     * WDTIFG -- Interrupt pending
     * 
     * Note: ~<BIT> indicates that <BIT> has value zero
     */
    IFG1 &= ~(WDTIFG);

    /* 
     * IE1, Interrupt Enable Register 1
     * 
     * ~ACCVIE -- Interrupt not enabled
     * ~NMIIE -- Interrupt not enabled
     * ~OFIE -- Interrupt not enabled
     * WDTIE -- Interrupt enabled
     * 
     * Note: ~<BIT> indicates that <BIT> has value zero
     */
    IE1 |= WDTIE;

}
