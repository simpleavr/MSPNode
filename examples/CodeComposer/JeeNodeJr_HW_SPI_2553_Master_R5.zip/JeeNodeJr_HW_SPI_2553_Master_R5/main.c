/*
 * ======== Standard MSP430 includes ========
 */
#include <msp430.h>
#include <msp430g2553.h> // <---<<< added for pragma - interrupts

/*
 * ======== Grace related includes ========
 */
#include <ti/mcu/msp430/csl/CSL.h>

/* GRACE is a "work of art" for MSP430Gx configuration setup.
 * For GRACE ref. only - inspect project files crc / csl for GRACE generated module 
 * specific setup bits
 * 
 * Grace eg main.cfg - Graphical setup pages
 * Grace overview page, Dvcc 3.3 VDC selected  
 * BCS+ clock page, basic --> 1 mhz dco, LSCS 32,767 Khz
 * BCS+ clock page, power user --> all divisors are 1, 12.5 pf for LSCS 
 * Flash page --> flash is enabled
 * WDT+ watchdog, basic -->  
 */


/*
 * ======== Other includes ========
 */
 

#define FCPU      1000000   // 1 mhz
//#define FCPU    8000000   // 8 mhz
//#define FCPU    12000000  // 12 mhz
//#define FCPU    16000000  // 16 mhz

#define USEC    (FCPU/1000000)


#ifdef MSP430
static void __inline__ __delay_cycles(register uint16_t n) {
//static void __inline__ brief_pause(register uint16_t n) {
    __asm__ __volatile__ (
                "1: \n"
                " dec      %[n] \n"
                " jne      1b \n"
        : [n] "+r"(n));

}
#else
#endif

// Red LED - on board on LaunchPad
#define led_off()       P1OUT &= ~BIT0
#define led_on()        P1OUT |= BIT0
#define led_flip()      P1OUT ^= BIT0

// Good data or ack yellow LED - added
#define ack_off()       P2OUT &= ~BIT5
#define ack_on()        P2OUT |= BIT5
#define ack_flip()      P2OUT ^= BIT5

#define max_tx_retries     10
#define transmit_mode   1         // 1 = multiple retries  2 = transmit once  

#include "rfm.h" 
#include "hw_uart.h"


/* Global variables
 * 
*/
static volatile uint8_t ticks = 0;
static volatile uint8_t tx_count =0;
static volatile long tx_stop_cnt =0;

static volatile uint8_t lockout =0;
uint16_t t =0; // for timedelay index on startup delay
static volatile uint8_t rx_tx_isr_cnt = 0; // for testing
static volatile uint16_t sr = 0; // status read for testing
static volatile uint8_t tx_retries = 0;
static volatile long test_retry_count = 0;
static volatile unsigned int rx_counter = 0;   

uint16_t t;
uint8_t v = 48; // starts with dec 0   

//==============================
// Destination nodeid
volatile unsigned char dest = 20; // <---<<< destination nodeId address (range - use only 1-30)   
//==============================

//=================================================
// Destination node packet array
//unsigned char payload[3];// Tx payload packet max 66
unsigned char payload[66];// Tx payload packet max 66
//=================================================

/* Program description:
 * 
 * Demostrates packet communications of the MSP430Gx JeeNodeJR and AVR JeeNode 
 * running the rfm12demo.  
 * 
 * 1 Hardware required: 32,768 khz crystal attached to MSP430Gx used for accurate
 *   watchdog cycle "tick" interval timer at 250 ms.
 * 2 One AVR JeeNode running rf12demo from Jeelabs.
 * 3 One MSP430Gx running this application program. 
 *
 * Be sure that both the MSP430Gx and the AVR JeeNode RFMdemo has the same RF baud rate
 * @ 4.8 kbaud for best RF coverage and distance.
 * For 4.8 kbuad, just put rf12_xfer(0xC647) in the rf12demo library cpp in function rf12_initialize();
 * Also, comment out the other rf12_xfer(0xC606); in the library 
 * // approx 49.2 Kbps, i.e. 10000/29/(1+6) Kbps 
 * 
 * The nodeid/grp setup used for this MSP430gx RF node is 8/1 and for the AVR JeeNode RFMdemo 20/1
 * Make sure the node and group is set-up in eeprom on the AVR JeeNode using the rf12demo.
 * Both node group numbers have to be the same and the nodeid's different!
 * This app has function "rf12_initialize(8, RF12_915MHZ, 1);" to setup the nodeID and group # 
 * The setup variable "dest" contains the nodeid of the remote AVR JeeNode for testing. 
 * 
 * This app program will transmit on power-on-reset (POR) or manual pushbutton reset 
 * a 66 data byte payload packet ('1','2','3') to another AVR Jeenode
 * running the rf12demo. 
 * 
 * If TX Mode 2 is selected (#define) the app will only transmit this paylod packet once.
 * 
 * TX Mode 1 will transmit this data packet with ack to make sure the data was sent properly.
 * TX Mode 1 has 10 max. retries and a "timeout" to almost guarantees packet payload transmission.       
 * 
 * This app will receive data packets sent from the AVR JeeNode using the Rfm12demo.
 * It will also ack (if requested) the data packet received. See rf12demo menu selections.  
 *  
 * rfm12demo commands supported:
 * t - broadcast max-size test packet, with ack
 * 1,2,3,<nn> a - send data packet to node <nn>, with ack
 * 1,2,3,<nn> s - send data packet to node <nn>, no ack
 * 
 * 
 * 
 * =====================================================================================
 *  
 *  
 * Status: TX OK RX OK with ack in both directions. 
 * Revision: 1.0b
 * Date: 9/18/11
 * Author: JeelabsAndy (with the help of simpleavr) 
 * 
 * JeeNodeJR priority development 

#1. Software SPI  SimpleAVR created this bit bang driver for the "included" LaunchPad MSP430Gx chips. OK - testing Done
#2. Hardware SPI  A must to have working for high end value line chips. OK Done
#3. Transmit to JeeNode AVR  -  using the rf12demo on the AVR. Done with SimpleAVR software HW SPI! OK - testing Done
#4. Receive from JeeNode AVR - using the rf12demo on the AVR. Done SimpleAVR software SPI only! OK - testing Done
#5. Hardware UART -  (software Uart is already made by SimpleAVR) low priority - CCS debegger will suffice
#6. Make the MSP430Gx code very power/battery friendly - use or insert the LP3 mode in the code "state mode" application 

   
 * Testing Status:
 * 
 * 9/14/11
 * Could not send continuous tx packets to the JeeNode at "full speed"
 * TX is now OK - needs 250 ms WD tick counter - reduced to 250 ms  
 * Works well at 1 mhz and 16 mhz. 1 mhx id used for best power savings.
 * tx canSend() needs blocked to prevent "RSSI xfer" from preventing receive loop from working.
 * 
 * 9/18/11
 * RX works at 1 Mhz (SW SPI) 
 * Added ack or good data yellow LED - P2.5 J12-13 (BIT5)
 * Turn on ack led with rxfill >= 6; // indicates good data 99% accurate? 
 * 
 * 9/19/11
 * HW SPI now works - needs much more testing !!!!
 * Added  HW_UART h file for 2553 data packet receive inspection (9600 baud max) in CCS 
 * 2553 TX RX leads needs to be reversed on the Lauchpad!  
 * Note: The 2553 was made after the LaunchPad was produced by TI.
 * 
 * 9/20/11 
 * Added ack reply on Tx packet from AVR JeeNode (if requested from the rf12demo)
 * Added ack to Tx data packet from MSP430G2553 JeeNodeJR to the AVR JeeNode. 
 * Changed max data bytes of 33 back to AVR JeeNode size of 66
 * Note: MSP430G2553 has plenty of ram resoures at 512 bytes. Other MSP430Gx vintages may not! 
 * All ack(s) in both directions are OK
 * Added two send packet tranmits TX modes - Mode 1 = multiple retries  Mode 2 =  single packet TX  
 * 
 *    
 * Code size: 1894 bytes flash and 80 data bytes   
*/

/*
 *  ======== main ========
 */
void main(void)
{
    CSL_init();            // Activate Grace-generated configuration
    
    P2IE &= ~0x08;         // Do NOT allow RFM12B GPIO interrupt to start!!!!
                           // RFM12B GPIO interrupt is enabled below.
                           
    // >>>>> Fill-in user code here <<<<<
       

// Do not write to the RF12 until after 150 ms of POR time - per Si4420 specs.
// Use after clock setup   
for (t=0;t<150;t++){  // 150 ms now  
__delay_cycles(1000); // 1000 usec
}    
    
ack_on(); //  yel LED on
_nop();
rf12_initialize(8, RF12_915MHZ, 1); // <------<<<< This node MSP430Gx node/grp
_nop();
ack_off(); // yel LED off

/*
// Test SPI to RFM12B interface Tx / Rx
rf12_xfer(0xC000); // force a LBD - test only
sr = rf12_xfer(0x0000); // check RFM12B status
_nop();
switch (sr){
  case 0x0400: break; // LBD
  case 0x0420: break; // LBD ATGL
  case 0x04A0: break; // LBD DQD ATGL
  case 0x0480: break; // LBD DQD
  case 0x0440: break; // LBD CTL
  case 0x0460: break; // LBD CTL ATGL
  case 0x0080: break; // DQD
  default: // trap it
     while(1){
     led_on(); // onboard red LED
     _nop();
     }//while	
}//switch
*/

//==========================================================
// GPIO Interrupt input pin setup (from RFM12B output nIRQ)
// Most other GPIO setup is done in GRACE
//==========================================================
// DO NOT CHANGE 
//
P1OUT |=  0x10;      // Set SPI SS high
//==========================================================
//P2OUT |=  0x08;    // Pullup on interrupt input from RF12B
//P2OUT &=  ~0x08;   // Pulldown on interrupt input from RF12B 
//P2REN |=  0x08;    // Enable pullup or pulldown resistor
// doesn't matter if interrupt pin is pulled up or down or none for the software SPI?
//==========================================================
//P2IES &=  ~0x08;   // Rising edge interrupt - Do not use with SimpleAVR software SPI driver!!!!
P2IES |=  0x08;      // Falling edge interrupt - Only use this interrupt edge with SimpleAVR HW SW SPI driver!!!!
//==========================================================
P2IFG &= ~0x08;      // Clear the RFM12B input interrupt flag   
P2IE  |=  0x08;      // Enable the RFM12B interrupt input after the rf12_initialize(); <----------<<<<<<<<<<<<
//==========================================================

__enable_interrupt(); // Set global interrupt enable (GIE)

// fill the payload array

for (t=0;t<66;t++) // 66 max
{
 payload[t] = v;
 v++;  	
}

  
while (1){
_nop();	

//payload[0] = 49; // '1'
//payload[1] = 50; // '2'
//payload[2] = 51; // '3'


	
	
	
 

if (ticks >= 1){ // every 1/4 sec @ 250 ms per WD isr tick -- was 1 sec
	             // uses ext 32k crystal for accuracy.
	            ticks = 0; //reset sec ticks (from watchdog ISR) 	            
                _nop();
                              
              //=============
              //Check receive
              //=============                            
                if (rf12_recvDone()) {	                 	
                    // Good data ?                                          
                    if (rf12_crc == 0) {
                    	if (rxfill >=6) { // OK --> good data with no SPI empty read error.
                        //ack_on(); // turn on yel ack LED
                        ack_flip(); // toggle yel ack LED                                           	                         
                    	} // end of rxfill
                    //=========================================
                    // check for ack from TX sender or source
                    // and reply immediately with ack in header
                    //=========================================
                      if (RF12_WANTS_ACK) {
                      rf12_sendStart(RF12_ACK_REPLY, 0, 0); // don't wait for canSend ????
                      }                   	 		                   
                   } // end of crc                      
                } // end of recDone                
              
                
             //==============  
             //Check transmit
             //==============
             // use number values 1 to 255 TX packets (default 1) 
             // On POR or reset, this routine will run once (adjustable) - for testing only
             // Also, check tranmit modes 1 & 2 define above for TX operation
             
             if ((tx_stop_cnt < 1)){    // do not bypass this if statement 
             //if ((tx_stop_cnt < 500)){    // do not bypass this if statement 
             //if ((tx_stop_cnt < 100000)){    // do not bypass this if statement               	
             	                        // it prevents a constant "xfer" RSSI from disturbing the receive function?                       
                unsigned char header=0; 
                tx_start:
                _nop(); 
                if (rf12_canSend()) { 	 	                           
                                                                                                      	
                        //==============================================================
                        // Transmit Mode 1 - with multiple retries "on no ack" from destination
                        // Send TX data packet and ask for destination nodeid to ack reply
                        // On NO reply ack - retry with a max of 10 retries
                        // guarantees TX data packet reception
                        //==============================================================
                        
                        if (transmit_mode == 1) {     
                        
                        
                        if (tx_retries >= max_tx_retries){
                        goto ack_fin;
                        }
                        	 
                        header |= RF12_HDR_DST | dest | RF12_HDR_ACK; // ack(1), dest(1), dest node ID <--------<<<<<<
                        rf12_sendStart(header, payload, sizeof payload); // send packet to dest       
                        // wait for ack_flag and transmit payload packet to finish
                        // need a better substitute for tx wait delay                                                
                        _delay_cycles(2000); // 2 ms
                        
                        _nop();//
                        
                             // ack is on its way? takes ~160 ms turnaround ack                           
                             //unsigned int rx_counter = 0;                             
                             ack_chk:
                             _delay_cycles(6000); // 6 ms used for (66 data) bytes                             
                             if (rx_counter <= 100){ // 100 ms                   
                                 if (rf12_recvDone() && rf12_crc == 0){
                                 ack_flip(); // toggle yel ack LED  
                                  goto ack_fin;
                                 } 
                             rx_counter++;
                             goto ack_chk;                                   
                             }                     
                             // ack reply >= than 100 ms - retry
                             tx_retries++;
                             test_retry_count++; // for test only
                             goto tx_start;                            
                        } // end of mode 1 TX
                        ack_fin: // ack receive check finished
                        _nop();
                        rx_counter = 0; // reset counter
                        tx_retries = 0; // reset retry                                      
                        //================================================
                        // Transmit Mode 2 - TX send packet once
                        // Send TX data packet with no ack reply requested
                        //================================================
                        
                        if (transmit_mode == 2) {                             	
                        header |= RF12_HDR_DST | dest; // !ack(0), dest(1), dest node ID <-----<<<<<<       
                        _nop();
                        rf12_sendStart(header, payload, sizeof payload);
                        _delay_cycles(1000); // 1 ms <--- packet ack timeout & transmit finish wait                         
                        } // end of mode 2
                                                                       
                        _nop();
                        tx_stop_cnt++;  
                                                                            
                }// end of need to send
            } // end of tx_stop_cnt                                                                               
       }// end of wd ticks       
    }// end of while   
} // end of main


//=========================================================================
//                            Interrupts
//=========================================================================

//===================
// WDT ISR
// Uses an ext 32k crystal (installed)
//===================

void WDT_INTERVAL_ISR(void)
{
_nop();
ticks++;
}

//============================
// PORT 2 GPIO RFM12B ISR
//============================
void PORT_2_RFM12B_ISR(void)
{
_BIC_SR(GIE); // clear GIE
led_on(); // onboard red LED
if (P2IFG & 0x08){     
_nop();
rf12_interrupt();
rx_tx_isr_cnt++;
_nop();
}//if
else {
_nop();        
}//else      
P2IFG &= ~0x08;               
led_off(); // onboard red LED
_BIS_SR(GIE); // set GIE
}//
//__________________________________________________________________________




//====================
// Development Notes
//====================
// My SPI is overlaid on top of the USCI_B0 hardware 
// 3 wire SPI module with GPIO SPI SS on the MSP430G2553
// for easy future expansion using the hardware SPI
//
// MSP430Gx P1.4 BIT4 SPI SS out  ----> 0x10 (J1-6)
// MSP430Gx P1.5 BIT5 SCK out     ----> 0x20 (J1-7)
// MSP430Gx P1.6 BIT6 SDI in      <---- 0x40 (J2-6)
// MSP430Gx P1.7 BIT7 SDO out     ----> 0x80 (J2-7)
//
// RFM12B Interrupt GPIO
// MSP430Gx P2.3 BIT3 Port 2      <---- 0x08 (J2-10) - with pullup ??? and falling edge
//
// The green LED light on the LaunchPad will show (flash) the data (SDI input) from the SPI RFM12B SDO output
// - very handy for troubleshooting.
//=========================================================================

/*
 *  
 * [JeeNode Protocol v2]

=================
Tx Packet Payload
=================
<---<<< Beginning Packet
3 byte preamble   0xAA  (outside rf12_buf)
1 byte sync       0x2D  (outside rf12_buf)
rf12_buf[0] 1 byte net group adjustable RFM12B - node group ID (in rf12_buf)
rf12_buf[1] 1 byte header src/dst/ack packet header            (in rf12_buf)
============================================================
CTL    DST     ACK      | Destination NodeId       |
ack 
reply                   16     8      4     2      1   BIN
8       4       2       1      8      4     2      1   HEX
7       6       5       4      3      2     1      0   BITS
0     SRC     NAck      |           0-31           |   <---------- Do not use 0, broadcast & 31 (special)
============================================================
Request of ack "from an external source node" with or w/o a TX data packet to 
this node will send back a ctl bit(1), src bit (0) and this NodeID address back to the source.

rf12_buf[2] 1 byte len - length of header 0.. 66 AVR and 37 in JeeNodeJR (in rf12_buf)
rf12_buf[rf12_buf+3 byte(s) up to 66 bytes of payload or 37 in JeeNodeJR (in rf12_buf)
2 byte(s) CRC16, little-endian (in rf12_buf)
<---<<< Ending Packet

3 data bytes will produce 13 bytes transmitted?
1 grp, 1 hdr, 1 des, 3 data  (in rf12_buf) + 
outside rf12_buf  3 preamble + 1 sync + 2 crc + 1 possible ending preamble 0xAA last byte.


===============================
Receive Rx Payload (in rf12_buf) (from TX source eg AVR JeeNode)
===============================
<---<<< Beginning Packet
group      rf12_buf[0] (in rf12_buf)
header     rf12_buf[1] (in rf12_buf) <---- Dest bit(1) and dest address [no ack(0)] from TX node source
                                     <---- Dest bit(1), ack bit(1), and dest address (ack) from TX node source
rf12_len   rf12_buf[2] (in rf12_buf) <---- Length is not fill in in rf12_buf is 0x00 ? (use rf12_len) 
rf12_buf[2] (in rf12_buf) 
rf12_data (rf12_buf+3) (in rf12_buf)
crc bytes (rf12_buf+x) (in rf12_buf)
<---<<< Ending Packet
===============================

Notes:
1 CRC16 data error checking is computed on the receive buffer payload
  if the crc16 is zero then the payload is OK.

2. rf12_buf is used for both tx and rx.
   includes header, data and crc bytes
   rf12_data[] array only includes the data bytes

RFM12B  Mode STATE for interrupts

// RF12 command codes
#define RF_RECEIVER_ON  0x82DD
#define RF_XMITTER_ON   0x823D
#define RF_IDLE_MODE    0x820D
#define RF_SLEEP_MODE   0x8205
#define RF_WAKEUP_MODE  0x8207
#define RF_TXREG_WRITE  0xB800
#define RF_RX_FIFO_READ 0xB000
#define RF_WAKEUP_TIMER 0xE000

enum states
0  TXCRC1
1  TXCRC2
2  TXTAIL
3  TXDONE
4  TXIDLE  = RF IDLE
5  TXRECV
6  TXPRE1
7  TXPRE2
8  TXPRE3
9  TXSYN1
10 TXSYN2

TXIDLE after rf12_initialize();
if there is a receive then it sets the receive and goes to TXREC
TXRECV from receive - no rec function add this mode for xmit
TXDONE after Tx packet transmission then back to RF_IDLE_Mode

========================================================
Testing HW SPI bit rate(s) - bits per second @ 1 MHZ DCO
========================================================

The MSP43Gx SPI can be either Hardware or Software "Bit Bang"
For the HW SPI, in the software, you can set the clock bps
For the SW "bit bang" SPI you need to get a frequency counter or O'scope out to find out 
the SPI clock bps.
  
fails at   5000 bps 200 us
fails at  10000 bps 100 us
passes at 50000 bps  20 us
passes at 100   kbps 10 us
passes at 256   kbps  3.9 us <--- same as the AVR JeeNode Arduino SPI HW
passes at 500   kbps  2 us   <--- 2x times as fast the AVR JeeNode Arduino SPI HW
                             <--- JeeNodeJr at 1 MHZ and AVR JeeNode Arduino at 16 Mhz
                             <--- JeeNodeJr will use less (MHZ) for better power savings at 2x the SPI speed.

RFM12B spec is ~ 256 kbps max <----- ???

==============================
Hardware and Software SPI setup
==============================

On the output of the RFM12B nIRQ to the input of the MSP430Gx you "may" need
a series current limit resistor (330 ohm) for current protection. 

The input of the MSP430Gx can be either pulled-up or pulled-down or
have no pullups or pulldowns at all for the RMF12B nIRQ interrupt output.

The interrupt signal input has to be a falling (not rising) edge trigger.
Won't work on the MSP430G2553 unless it is falling! (On both HW  & SW SPI)

===============
SPI data stream
===============
The standard SPI mode to interface to the RFM12B is MODE 0. (PLOL=0 & CPHA=0)

Clock level: 
clock idle low CPOL=0 (CPOL=0 the base value of the clock is zero)

Clock phase:  
For CPHA=0, data are captured on the clock's rising edge 
(low -->high transition) and data are propagated on a falling edge 
(high-->low clock transition).

MSB first

8 bit
*/




