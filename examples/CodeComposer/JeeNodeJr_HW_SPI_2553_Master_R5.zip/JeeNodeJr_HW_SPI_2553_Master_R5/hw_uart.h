#ifndef HW_UART_H_
#define HW_UART_H_
/* Originally version from:
http://www.msp430launchpad.com/2010/08/half-duplex-software-uart-on-launchpad.html
*/

// G2553 RXD on P1.1 LaunchPad
// G2553 TXD on P1.2 LaunchPad 
// To use the CCS terminal program @ 9600 max swap the tx rx on the header!
// All setup code done in GRACE --> 9600, 8,N,1
// Uses ext watch crystal for clock

static volatile uint8_t toSend = 0;

static volatile unsigned int TXByte; // Value sent over UART when uart_putc() is called
static volatile unsigned int RXByte; // Value recieved once hasRecieved is set

static volatile char isReceiving = 0; // Status for when the device is receiving
static volatile char hasReceived = 0; // Lets the program know when a byte is received

//______________________________________________________________________
char uart_getc(uint8_t *c) {
    if (!hasReceived)
        return 0;
    *c = RXByte;
    hasReceived = 0;
        toSend = 1;
    return 1;
}
//______________________________________________________________________
void uart_putc(uint8_t c) {
        //if (toSend) {
        	
        	
        	   //  UCA0TXBUF = UCA0RXBUF;  // TX -> RXed character
        	   
                //TXByte = c;
                //TXByte |= 0x100; // Add stop bit to TXByte (which is logical 1)
                //TXByte = TXByte << 1; // Add start bit (which is logical 0)

                //while (isReceiving); // Wait for RX completion

                //CCTL0 = OUT; // TXD Idle as Mark
                //TACTL = TASSEL_2 + MC_2; // SMCLK, continuous mode

                //bitCount = 0xA; // Load Bit counter, 8 bits + ST/SP
                //CCR0 = TAR; // Initialize compare register
                //CCR0 += BIT_TIME; // Set time till first bit

                //CCTL0 = CCIS0 + OUTMOD0 + CCIE; // Set signal, intial value, enable interrupts

                //while ( CCTL0 & CCIE ); // Wait for previous TX completion
        //}//if
        
        // No interrupts
        TXByte = c;
        UCA0TXBUF = TXByte;
        //while ( CCTL0 & CCIE ); // Wait for previous TX completion
        
}

//______________________________________________________________________
void uart_puts(const char *str) {
    while(*str!=0)
        uart_putc(*str++);
}

//______________________________________________________________________
static char nibble_to_char(uint8_t nibble) {
    if (nibble < 0xA)
        return nibble + '0';
    return nibble - 0xA + 'A';
}

//______________________________________________________________________
void uart_puthex8(uint8_t h) {
    uart_putc(nibble_to_char((h & 0xF0)>>4));
    uart_putc(nibble_to_char(h & 0x0F));
}

//______________________________________________________________________
void uart_puthex32(uint32_t h) {
    uart_puthex8((h & 0xFF000000) >> 24);
    uart_puthex8((h & 0x00FF0000) >> 16);
    uart_puthex8((h & 0x0000FF00) >> 8);
    uart_puthex8(h & 0xFF);
}

//______________________________________________________________________
void uart_puthex16(uint16_t h) {
    uart_puthex8((h & 0xFF00) >> 8);
    uart_puthex8(h & 0xFF);
}

//______________________________________________________________________

#endif /*HW_UART_H_*/
