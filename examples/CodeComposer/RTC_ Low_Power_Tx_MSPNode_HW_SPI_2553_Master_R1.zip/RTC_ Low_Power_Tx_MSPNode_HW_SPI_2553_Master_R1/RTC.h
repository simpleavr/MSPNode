#ifndef RTC_H_
#define RTC_H_
// Program without any charge or restriction.  You may
// distribute to third parties, provided that you transfer a
// copy of this license to the third party and the third party
// agrees to these terms by its first use of the Program. You
// must reproduce the copyright notice and any other legend of
// ownership on each copy or partial copy, of the Program.
//
// You acknowledge and agree that the Program contains
// copyrighted material, trade secrets and other TI proprietary
// information and is protected by copyright laws,
// international copyright treaties, and trade secret laws, as
// well as other intellectual property laws.  To protect TI's
// rights in the Program, you agree not to decompile, reverse
// engineer, disassemble or otherwise translate any object code
// versions of the Program to a human-readable form.  You agree
// that in no event will you alter, remove or destroy any
// copyright notice included in the Program.  TI reserves all
// rights not specifically granted under this license. Except
// as specifically provided herein, nothing in this agreement
// shall be construed as conferring by implication, estoppel,
// or otherwise, upon you, any license or other right under any
// TI patents, copyrights or trade secrets.
//
// You may not use the Program in non-TI devices.
//
//******************************************************************************
#ifndef RTC_H
#define RTC_H

#define setTime(H,M,S,P) {TI_second = S; TI_minute = M; TI_hour = H; TI_PM = P;} // encoded as BCD chars

extern char TI_second;      // 0x00 - 0x59
extern char TI_minute;      // 0x00 - 0x59
extern char TI_hour;        // 0x00 - 0x12
extern char TI_PM;          // AM = 0, PM = 1

extern void incrementSeconds(void);
extern void incrementMinutes(void);
extern void incrementHours(void);
extern char get24Hour(void);

#endif

#endif /*RTC_H_*/
