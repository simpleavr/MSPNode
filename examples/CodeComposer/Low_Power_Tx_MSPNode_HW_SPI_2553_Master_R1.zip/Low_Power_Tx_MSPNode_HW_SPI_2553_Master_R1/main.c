/*
 * ======== Standard MSP430 includes ========
 */
#include <msp430.h>
#include <msp430g2553.h> // <---<<< added for pragma - interrupts

/*
 * ======== Grace related includes ========
 */
#include <ti/mcu/msp430/csl/CSL.h>


/*
 * ======== Other includes ========
 */
 

#define FCPU      1000000   // 1 mhz
//#define FCPU    8000000   // 8 mhz
//#define FCPU    12000000  // 12 mhz
//#define FCPU    16000000  // 16 mhz

#define USEC    (FCPU/1000000)


#ifdef MSP430
static void __inline__ __delay_cycles(register uint16_t n) {
//static void __inline__ brief_pause(register uint16_t n) {
    __asm__ __volatile__ (
                "1: \n"
                " dec      %[n] \n"
                " jne      1b \n"
        : [n] "+r"(n));

}
#else
#endif

// Red LED - on board on LaunchPad
#define led_off()       P1OUT &= ~BIT0
#define led_on()        P1OUT |= BIT0
#define led_flip()      P1OUT ^= BIT0

// Good data or ack yellow LED - added
#define ack_off()       P2OUT &= ~BIT5
#define ack_on()        P2OUT |= BIT5
#define ack_flip()      P2OUT ^= BIT5

#define max_tx_retries     10
#define transmit_mode       2         // 1 = multiple retries  2 = transmit once  

#include "rfm.h" 
#include "hw_uart.h"


/* Global variables
 * 
*/
static volatile uint8_t ticks = 0;
static volatile uint8_t tx_count =0;
static volatile long tx_stop_cnt =0;

static volatile uint8_t lockout =0;
uint16_t t =0; // for timedelay index on startup delay
static volatile uint8_t rx_tx_isr_cnt = 0; // for testing
static volatile uint16_t sr = 0; // status read for testing
static volatile uint8_t tx_retries = 0;
static volatile long test_retry_count = 0;
static volatile unsigned int rx_counter = 0;

static volatile unsigned int tx_sec_max = 22; // 22 * 2.7 ~61.sec +- 10%  

uint16_t t;
uint8_t v = 48; // starts with dec 0   

//==============================
// Destination nodeid
volatile unsigned char dest = 20; // <---<<< destination nodeId address (range - use only 1-30)   
//==============================

//=================================================
// Destination node packet array
unsigned char payload[66];// Tx payload packet max 66
//=================================================

/* Program description:
 * 
 * Demostrates low power management LP3 mode and the rfm12_sleep() function using Tx packet 
 * communications of the MSP430Gx MSPNode and AVR JeeNode running the rfm12demo.
 * In both the MSPNode LP3 and RFM12B sleep the standby current is ~ 1 uA.  
 * 
 *  Hardware required
 *  One AVR JeeNode running rf12demo v 2.0 from Jeelabs.
 *  One MSP430Gx MSPNode running this application program. 
 *
 * Be sure that both the MSP430Gx and the AVR JeeNode RFMdemo has the same RF baud rate
 * @ 4.8 kbaud for best RF coverage and distance.
 * For 4.8 kbuad, just put rf12_xfer(0xC647) in the rf12demo library cpp in function rf12_initialize();
 * Also, comment out the other rf12_xfer(0xC606); in the library 
 * // approx 49.2 Kbps, i.e. 10000/29/(1+6) Kbps 
 * 
 * The nodeid/grp setup used for this MSP430gx RF node is 8/1 and for the AVR JeeNode RFMdemo 20/1
 * Make sure the node and group is set-up in eeprom on the AVR JeeNode using the rf12demo.
 * Both node group numbers have to be the same and the nodeid's different!
 * This app has function "rf12_initialize(8, RF12_915MHZ, 1);" to setup the nodeID and group # 
 * The setup variable "dest" contains the nodeid of the remote AVR JeeNode for testing. 
 * 
 * This app program will transmit on power-on-reset (POR) or manual pushbutton reset 
 * a 66 data byte payload packet ('1','2','3') to another AVR Jeenode
 * running the rf12demo. 
 *  
 * TX Mode 1 will transmit this data packet with ack to make sure the data was sent properly.
 * TX Mode 1 has 10 max. retries and a "timeout" to almost guarantees packet payload transmission.       
 * 
 * If TX Mode 2 is selected (#define) the app will only transmit this paylod packet once.
 * 
 * 
 * =====================================================================================
 *   
 * Code size: 1910 bytes flash and 84 data bytes   
*/

/*
 *  ======== main ========
 */
void main(void)
{
    CSL_init();            // Activate Grace-generated configuration
    
    P2IE &= ~0x08;         // Do NOT allow RFM12B GPIO interrupt to start!!!!
                           // RFM12B GPIO interrupt is enabled below.
                           
    // >>>>> Fill-in user code here <<<<<
       

// Do not write to the RF12 until after 150 ms of POR time - per Si4420 specs.
// Use after clock setup   
for (t=0;t<150;t++){  // 150 ms now  
__delay_cycles(1000); // 1000 usec
}    
    
ack_on(); //  yel LED on
_nop();
rf12_initialize(8, RF12_915MHZ, 1); // <------<<<< This node MSP430Gx node/grp
_nop();
ack_off(); // yel LED off



//==========================================================
// GPIO Interrupt input pin setup (from RFM12B output nIRQ)
// Most other GPIO setup is done in GRACE
//==========================================================
// DO NOT CHANGE 
//
P1OUT |=  0x10;      // Set SPI SS high
//==========================================================
//P2OUT |=  0x08;    // Pullup on interrupt input from RF12B
//P2OUT &=  ~0x08;   // Pulldown on interrupt input from RF12B 
//P2REN |=  0x08;    // Enable pullup or pulldown resistor
// doesn't matter if interrupt pin is pulled up or down or none for the software SPI?
//==========================================================
//P2IES &=  ~0x08;   // Rising edge interrupt - Do not use with SimpleAVR software SPI driver!!!!
P2IES |=  0x08;      // Falling edge interrupt - Only use this interrupt edge with SimpleAVR HW SW SPI driver!!!!
//==========================================================
P2IFG &= ~0x08;      // Clear the RFM12B input interrupt flag   
P2IE  |=  0x08;      // Enable the RFM12B interrupt input after the rf12_initialize(); <----------<<<<<<<<<<<<
//==========================================================

__enable_interrupt(); // Set global interrupt enable (GIE)

// fill the payload array

for (t=0;t<66;t++) // 66 max
{
 payload[t] = v;
 v++;  	
}

  
while (1){
_nop();	

     if (ticks >= tx_sec_max){ // Uses VLO @ 2.7 secs ~ 1 min between transmits
     _nop();	
     ticks = 0; //reset sec ticks (from watchdog ISR)
     unsigned char header=0;  	            
     _nop();
     // wake-up the RF12B radio transceiver
     rf12_sleep(RF12_WAKEUP); // rxstate = TXIDLE & RF_IDLE_MODE <----- RF12B internal clock on ~ 0.62-1.2ma 
     // prepare the RFM12B to send and receive
      
     while (rf12_recvDone()); // Needed
                       
             //===========================  
             //Transmit/send payload packet
             //===========================                     
                tx_start:
                _nop(); 
                //if (rf12_canSend()) { 	
                while (!(rf12_canSend())); 	 	                           
                                                                                                      	
                        //==============================================================
                        // Transmit Mode 1 - with multiple retries "on no ack" from destination
                        // Send TX data packet and ask for destination nodeid to ack reply
                        // On NO reply ack - retry with a max of 10 retries
                        // guarantees TX data packet reception
                        //==============================================================
                        
                        if (transmit_mode == 1) {     
                        
                        
                        if (tx_retries >= max_tx_retries){
                        goto ack_fin;
                        }
                        	 
                        header |= RF12_HDR_DST | dest | RF12_HDR_ACK; // ack(1), dest(1), dest node ID <--------<<<<<<
                        rf12_sendStart(header, payload, sizeof payload); // send packet to dest       
                        // wait for ack_flag and transmit payload packet to finish
                        // need a better substitute for tx wait delay                                                
                        _delay_cycles(2000); // 2 ms
                        
                        _nop();//
                        
                             // ack is on its way? takes ~160 ms turnaround ack                           
                             //unsigned int rx_counter = 0;                             
                             ack_chk:
                             _delay_cycles(6000); // 6 ms used for (66 data) bytes                             
                             if (rx_counter <= 100){ // 100 ms                   
                                 if (rf12_recvDone() && rf12_crc == 0){
                                 ack_flip(); // toggle yel ack LED  
                                  goto ack_fin;
                                 } 
                             rx_counter++;
                             goto ack_chk;                                   
                             }                     
                             // ack reply >= than 100 ms - retry
                             tx_retries++;
                             test_retry_count++; // for test only
                             goto tx_start;                            
                        } // end of mode 1 TX
                        ack_fin: // ack receive check finished
                        _nop();
                        rx_counter = 0; // reset counter
                        tx_retries = 0; // reset retry
                                                              
                        //================================================
                        // Transmit Mode 2 - TX send packet once
                        // Send TX data packet with no ack reply requested
                        //================================================
                        
                        if (transmit_mode == 2) {                             	
                        header |= RF12_HDR_DST | dest; // !ack(0), dest(1), dest node ID <-----<<<<<<       
                        _nop();
                        rf12_sendStart(header, payload, sizeof payload);
                        _delay_cycles(1000); // 1 ms <--- packet ack timeout & transmit finish wait                         
                        } // end of mode 2
                                                                       
                        _nop();
                        tx_stop_cnt++;  
                                                                            
                //}// end of need to send
                
                // wait out all current receives and sends
                while ((rxstate != TXIDLE && rxstate != TXRECV));
                // power down rfm12b module
                rf12_sleep(RF12_SLEEP); // <----- internal clock off 0.3 ua 
                                                                                                                           
       }// end of VLO ticks
       
       // Not ready to transmit?
       // Note: all interrupts keep the MSP430Gx in "active mode" "after its interrupt!"
       _nop();
       _bis_SR_register(LPM3_bits + GIE); // <----- ~ < 5 uA 
       // Measure current = 1.09 uA <------- without GPIO conditioning.
                          
    }// end of while   
} // end of main


//=========================================================================
//                            Interrupts
//=========================================================================

//===================
// WDT ISR
// Uses the VLO 12KHZ internal clock @ 4.7 secs.
//===================

void WDT_INTERVAL_ISR(void)
{
_nop();
ticks++;
//active mode after interrupt
}

//============================
// PORT 2 GPIO RFM12B ISR
//============================
void PORT_2_RFM12B_ISR(void)
{
_BIC_SR(GIE); // clear GIE
led_on(); // onboard red LED
if (P2IFG & 0x08){     
_nop();
rf12_interrupt();
rx_tx_isr_cnt++;
_nop();
}//if
else {
_nop();        
}//else      
P2IFG &= ~0x08;               
led_off(); // onboard red LED
_BIS_SR(GIE); // set GIE
// active mode after interrupt
}//
//__________________________________________________________________________




//====================
// Development Notes
//====================
// My SPI is overlaid on top of the USCI_B0 hardware 
// 3 wire SPI module with GPIO SPI SS on the MSP430G2553
// for easy future expansion using the hardware SPI
//
// MSP430Gx P1.4 BIT4 SPI SS out  ----> 0x10 (J1-6)
// MSP430Gx P1.5 BIT5 SCK out     ----> 0x20 (J1-7)
// MSP430Gx P1.6 BIT6 SDI in      <---- 0x40 (J2-6)
// MSP430Gx P1.7 BIT7 SDO out     ----> 0x80 (J2-7)
//
// RFM12B Interrupt GPIO
// MSP430Gx P2.3 BIT3 Port 2      <---- 0x08 (J2-10) - with pullup ??? and falling edge
//
// The green LED light on the LaunchPad will show (flash) the data (SDI input) from the SPI RFM12B SDO output
// - very handy for troubleshooting.
//=========================================================================

/*
 *  
 * [JeeNode Protocol v2]

=================
Tx Packet Payload
=================
<---<<< Beginning Packet
3 byte preamble   0xAA  (outside rf12_buf)
1 byte sync       0x2D  (outside rf12_buf)
rf12_buf[0] 1 byte net group adjustable RFM12B - node group ID (in rf12_buf)
rf12_buf[1] 1 byte header src/dst/ack packet header            (in rf12_buf)
============================================================
CTL    DST     ACK      | Destination NodeId       |
ack 
reply                   16     8      4     2      1   BIN
8       4       2       1      8      4     2      1   HEX
7       6       5       4      3      2     1      0   BITS
0     SRC     NAck      |           0-31           |   <---------- Do not use 0, broadcast & 31 (special)
============================================================
Request of ack "from an external source node" with or w/o a TX data packet to 
this node will send back a ctl bit(1), src bit (0) and this NodeID address back to the source.

rf12_buf[2] 1 byte len - length of header 0.. 66 AVR and 37 in JeeNodeJR (in rf12_buf)
rf12_buf[rf12_buf+3 byte(s) up to 66 bytes of payload or 37 in JeeNodeJR (in rf12_buf)
2 byte(s) CRC16, little-endian (in rf12_buf)
<---<<< Ending Packet

3 data bytes will produce 13 bytes transmitted?
1 grp, 1 hdr, 1 des, 3 data  (in rf12_buf) + 
outside rf12_buf  3 preamble + 1 sync + 2 crc + 1 possible ending preamble 0xAA last byte.


===============================
Receive Rx Payload (in rf12_buf) (from TX source eg AVR JeeNode)
===============================
<---<<< Beginning Packet
group      rf12_buf[0] (in rf12_buf)
header     rf12_buf[1] (in rf12_buf) <---- Dest bit(1) and dest address [no ack(0)] from TX node source
                                     <---- Dest bit(1), ack bit(1), and dest address (ack) from TX node source
rf12_len   rf12_buf[2] (in rf12_buf) <---- Length is not fill in in rf12_buf is 0x00 ? (use rf12_len) 
rf12_buf[2] (in rf12_buf) 
rf12_data (rf12_buf+3) (in rf12_buf)
crc bytes (rf12_buf+x) (in rf12_buf)
<---<<< Ending Packet
===============================

Notes:
1 CRC16 data error checking is computed on the receive buffer payload
  if the crc16 is zero then the payload is OK.

2. rf12_buf is used for both tx and rx.
   includes header, data and crc bytes
   rf12_data[] array only includes the data bytes

RFM12B  Mode STATE for interrupts

// RF12 command codes
 * // RF12 command codes
#define RF_RECEIVER_ON  0x82DD <----- rx on 11-13 ma
#define RF_XMITTER_ON   0x823D <----- tx on 24-26 ma
#define RF_IDLE_MODE    0x820D <----- internal clock on 0.62-1.2ma
#define RF_SLEEP_MODE   0x8205 <----- internal clock off 0.3 ua 
#define RF_WAKEUP_MODE  0x8207 <----- wake from sleep mode
#define RF_TXREG_WRITE  0xB800
#define RF_RX_FIFO_READ 0xB000
#define RF_WAKEUP_TIMER 0xE000 <----- not used unstable WD ???
 * 

enum states
0  TXCRC1
1  TXCRC2
2  TXTAIL
3  TXDONE
4  TXIDLE  = RF IDLE
5  TXRECV
6  TXPRE1
7  TXPRE2
8  TXPRE3
9  TXSYN1
10 TXSYN2

TXIDLE after rf12_initialize();
if there is a receive then it sets the receive and goes to TXREC
TXRECV from receive - no rec function add this mode for xmit
TXDONE after Tx packet transmission then back to RF_IDLE_Mode

========================================================
Testing HW SPI bit rate(s) - bits per second @ 1 MHZ DCO
========================================================

The MSP43Gx SPI can be either Hardware or Software "Bit Bang"
For the HW SPI, in the software, you can set the clock bps
For the SW "bit bang" SPI you need to get a frequency counter or O'scope out to find out 
the SPI clock bps.
  
fails at   5000 bps 200 us
fails at  10000 bps 100 us
passes at 50000 bps  20 us
passes at 100   kbps 10 us
passes at 256   kbps  3.9 us <--- same as the AVR JeeNode Arduino SPI HW
passes at 500   kbps  2 us   <--- 2x times as fast the AVR JeeNode Arduino SPI HW
                             <--- JeeNodeJr at 1 MHZ and AVR JeeNode Arduino at 16 Mhz
                             <--- JeeNodeJr will use less (MHZ) for better power savings at 2x the SPI speed.

RFM12B spec is ~ 256 kbps max <----- ???

==============================
Hardware and Software SPI setup
==============================

On the output of the RFM12B nIRQ to the input of the MSP430Gx you "may" need
a series current limit resistor (330 ohm) for current protection. 

The input of the MSP430Gx can be either pulled-up or pulled-down or
have no pullups or pulldowns at all for the RMF12B nIRQ interrupt output.

The interrupt signal input has to be a falling (not rising) edge trigger.
Won't work on the MSP430G2553 unless it is falling! (On both HW  & SW SPI)

===============
SPI data stream
===============
The standard SPI mode to interface to the RFM12B is MODE 0. (PLOL=0 & CPHA=0)

Clock level: 
clock idle low CPOL=0 (CPOL=0 the base value of the clock is zero)

Clock phase:  
For CPHA=0, data are captured on the clock's rising edge 
(low -->high transition) and data are propagated on a falling edge 
(high-->low clock transition).

MSB first

8 bit
//================
   Power Save
//================
Power battery management options for both MSP430Gx and RFM12B

General RFM12B per Hope RF spec.
Min/Max Vdd    2.2-3.8 VDC
RFM12B sleep mode (with internal clock off)
= 0.3 uA <-----<<<<
TX 24-26 ma Pmax @ 915 MHZ <----<<<<
RX 11-13 ma <------<<<<
RFM12B idle current (Crystal osc on) Min/Max 0.62 - 1.2 ma <---<<<<

General: for MSP430G2553 per TI spec. 
Min/Max Supply 1.8 - 3.6 VDC

"The MSP430Gx was made from the ground up for low power operation"
 
Five Power-Saving Modes

Operating Modes For Basic Clock System MSP430Gx
0 0 0 0 Active CPU is active, all enabled clocks are active. (now power savings)
0 0 0 1 LPM0 MCLK are disabled. DCO and DC generator are disabled if the DCO is not used for SMCLK. ACLK is active.                                                                   
0 1 0 1 LPM1 disabled if the DCO is not used for SMCLK. ACLK is active.
1 0 0 1 LPM2 CPU, MCLK, SMCLK, DCO are disabled. DC generator remains enabled. ACLK is active.
1 1 0 1 LPM3 CPU, MCLK, SMCLK, DCO are disabled. DC generator disabled. ACLK is active.
1 1 1 1 LPM4 CPU and all clocks disabled

Ultra-Low Power Consumption MSP430Gx
- Active Mode: 230 uA at 1 Mhz, 2.2 V
- Standby Mode: 0.5 uA
- Off Mode (RAM Rentention): 0.1 uA
MSP430G2553 LP3 power mode

To save power on unused GPIO pins
Px.0 to Px.7 Open Switched to port function, output direction or input 
with pullup/pulldown enabled 

Notes:
For Low-Power Operation
Power draw increase with
1 VCC
2 CPU clock speed (master clock)
3 Temperature

Slowing MCLK reduces instantaneous power,
but usually increase active duty cycle

Power saving can be nullified
The Ultra Low Power "sweet spot" that maximizes performance
for the minimum current consumption per MIPS: 8 Mhz MCLK 
Full operating range (down to 2.2 v)
Optimize core voltage for chosen MCLK speed.
    
*/




